package cafe2;

public class Cafe {
    private Coffee[] coffeeList = new Coffee[10];
    private static Cafe cafe = new Cafe(); //싱글톤으로 변경
    private Cafe(){//싱글톤 접근불가
    }
    private int idx;

    public static Cafe getCafe(){
        return cafe;
    }


    public int totalPrice(){
        int sum = 0; // 어차피 반환하고 없어져도 되기때문에 로컬변수 선언
        for (int i = 0; i < idx; i++) { //인덱스만큼 for문을 돌리고
            sum += coffeeList[i].getPrice(); // coffee 배열에 있는 값들을 sum에 다 더하고
        }
        return sum; // 반환
    }

    public Coffee[] getCoffeeList() {
        //**메인에서 idx를 사용하고 싶지 않아서 아래에서 애초에 인덱스만큼만 반환하도록 변경
        Coffee[] retCoffe = new Coffee[idx]; // 인덱스만큼만 선언   어차피 반환하고 없어져도 되기때문에 로컬변수 선언
        for(int i = 0; i < idx; i++) {
            retCoffe[i] = coffeeList[i]; // 배열에 담아서
        }
        return retCoffe; //리턴
    }
    public void setCoffeeList(Coffee coffee){
        if(idx < 10){//10개가 넘는지 확인
            coffeeList[idx] = coffee; // 메인에서 받아오는 coffee객체를 배열에 저장
            idx++;  //set 될 때 마다 증가하며 몇개 들어가는지 확인
        }
        else{
            System.out.println("정보 추가가 될 수 없습니다.");
        }
    }
}
