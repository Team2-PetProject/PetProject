package cafe2;

public class CafeTest {
    public static void main(String[] args) {
        Cafe cafe = Cafe.getCafe(); // 싱글톤 때문에 접근제한 이런식으로 사용함
        cafe.setCoffeeList(new Coffee("아메리카노", 1000));
        cafe.setCoffeeList(new Coffee("라떼", 1000));
        cafe.setCoffeeList(new Coffee("블루베리", 1000));
        cafe.setCoffeeList(new Coffee("아메리카노", 1000));
//        cafe.setCoffeeList(new Coffee("라떼", 1000));
//        cafe.setCoffeeList(new Coffee("블루베리", 1000));
//        cafe.setCoffeeList(new Coffee("아메리카노", 1000));
//        cafe.setCoffeeList(new Coffee("라떼", 1000));
//        cafe.setCoffeeList(new Coffee("블루베리", 1000));
//        cafe.setCoffeeList(new Coffee("블루베리", 1000));
        cafe.setCoffeeList(new Coffee("블루베리", 1000));

        //이부분에서 조건이나 반환 등 다른걸 변경하고 싶지 않아서 Cafe객체 함수를 수정하는 방식
        System.out.println(cafe.totalPrice());
        Coffee[] arr = cafe.getCoffeeList(); //
        for (Coffee coffee : arr) { //여기서 이형식을 버리고 싶지 않아서 Cafe에서 함수에서 처리
            System.out.println(coffee);
        }
    }
}
